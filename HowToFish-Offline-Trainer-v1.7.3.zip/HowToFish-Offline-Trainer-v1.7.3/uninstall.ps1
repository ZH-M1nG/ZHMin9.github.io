[CmdletBinding()]
param(
    [string]$GamePath = 'D:\Steam\steamapps\common\How to Fish'
)

$ErrorActionPreference = 'Stop'

function Resolve-GameRoot {
    param([string]$RequestedPath)

    $resolved = (Resolve-Path -LiteralPath $RequestedPath).Path
    foreach ($candidate in @($resolved, (Join-Path $resolved 'How to Fish'))) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'How to Fish.exe') -PathType Leaf) {
            return $candidate
        }
    }

    throw "在 '$RequestedPath' 或其 How to Fish 子目录中找不到 How to Fish.exe。"
}

$gameRoot = Resolve-GameRoot -RequestedPath $GamePath
$targets = @(
    (Join-Path $gameRoot 'BepInEx\plugins\HowToFishOfflineTrainer.dll'),
    (Join-Path $gameRoot 'BepInEx\plugins\HowToFishOfflineTrainer.pdb'),
    (Join-Path $gameRoot 'BepInEx\plugins\AimAssistNotice.wav'),
    (Join-Path $gameRoot 'BepInEx\config\local.howtofish.offline.trainer.cfg')
)

$removed = 0
foreach ($target in $targets) {
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        Remove-Item -LiteralPath $target -Force
        Write-Host "已删除：$target"
        $removed++
    }
}

Write-Host "卸载完成，共删除 $removed 个本修改器文件。" -ForegroundColor Green
Write-Host 'BepInEx 已保留，以免影响其他模组。'
