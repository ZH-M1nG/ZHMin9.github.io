using System;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

[assembly: AssemblyVersion("1.7.3.0")]
[assembly: AssemblyFileVersion("1.7.3.0")]

namespace HowToFishOfflineTrainer
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public sealed class TrainerPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "local.howtofish.offline.trainer";
        public const string PluginName = "How to Fish Offline Trainer";
        public const string PluginVersion = "1.7.3";

        private const BindingFlags AnyStatic = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
        private const BindingFlags AnyInstance = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        private ConfigEntry<KeyboardShortcut> _panelKey;
        private ConfigEntry<KeyboardShortcut> _addMoneyKey;
        private ConfigEntry<KeyboardShortcut> _godModeKey;
        private ConfigEntry<KeyboardShortcut> _fullnessKey;
        private ConfigEntry<KeyboardShortcut> _speedKey;
        private ConfigEntry<KeyboardShortcut> _jumpKey;
        private ConfigEntry<KeyboardShortcut> _damageKey;
        private ConfigEntry<KeyboardShortcut> _healthKey;
        private ConfigEntry<KeyboardShortcut> _shinyKey;
        private ConfigEntry<KeyboardShortcut> _gambleKey;
        private ConfigEntry<KeyboardShortcut> _slotRarityKey;
        private ConfigEntry<KeyboardShortcut> _fovKey;
        private ConfigEntry<KeyboardShortcut> _fpsOverlayKey;
        private ConfigEntry<KeyboardShortcut> _aimAssistKey;
        private ConfigEntry<KeyboardShortcut> _disableKey;

        private static TrainerPlugin _instance;

        private Rect _window = new Rect(24f, 55f, 430f, 720f);
        private Vector2 _scrollPosition;
        private bool _showPanel = true;
        private bool _fullnessLock;
        private bool _requestedGodMode;
        private float _moveMultiplier = 1f;
        private float _jumpMultiplier = 1f;
        private float _damageMultiplier = 1f;
        private float _healthMultiplier = 1f;
        private bool _shinyOverrideEnabled;
        private int _shinyChance = 25;
        private bool _gambleOverrideEnabled;
        private int _gambleWinChance = 75;
        private bool _slotRarityOverrideEnabled;
        private int _slotRarity = 3;
        private object _lastSelectedBetColor;
        private bool _fovOverrideEnabled;
        private float _cameraFov = 90f;
        private bool _fpsOverlayEnabled = true;
        private float _smoothedFrameTime = 1f / 60f;
        private bool _onlineModeActive;
        private bool _aimAssistEnabled;
        private float _aimAssistSpeedMultiplier = 6f;
        private float _aimAssistAcquireAngle = 35f;
        private float _aimAssistLeadSeconds = 0.12f;
        private string _currentLobbyIdentity = string.Empty;
        private bool _consentConfirmedForLobby;
        private bool _voiceNoticePlayedForLobby;
        private AudioClip _aimAssistNoticeClip;
        private bool _voiceLoadAttempted;
        private float _nextVitalsUpdate;
        private float _nextResolveAttempt;
        private string _lastAction = "等待进入离线存档";

        private Assembly _gameAssembly;
        private Type _playerType;
        private Type _moneyManagerType;
        private Type _playerManagerType;
        private Type _saveManagerType;
        private Type _connectionManagerType;
        private Type _creatureManagerType;
        private Type _creatureType;
        private Type _serverType;
        private Type _playerVitalsType;
        private Type _casinoManagerType;
        private Type _slotMachineManagerType;
        private Type _slotMachineType;
        private Type _skinPresetType;
        private Type _itemType;
        private Type _boatManagerType;
        private Type _boatType;
        private Type _betColorType;
        private Type _rarityType;
        private Type _playerAimAssistType;
        private Type _steamManagerType;
        private FieldInfo _localPlayerField;
        private FieldInfo _isUsingSteamField;
        private FieldInfo _connectionManagerInstanceField;
        private FieldInfo _networkManagerField;
        private FieldInfo _aimAssistPlayerField;
        private FieldInfo _aimAssistMaxTargetDistanceField;
        private FieldInfo _aimAssistAcquireAngleField;
        private FieldInfo _aimAssistTrackingBreakAngleField;
        private FieldInfo _aimAssistTargetScanIntervalField;
        private FieldInfo _aimAssistMaxRotationSpeedField;
        private FieldInfo _aimAssistTrackingSharpnessField;
        private FieldInfo _creatureManagerInstanceField;
        private FieldInfo _shinyCreatureChanceField;
        private FieldInfo _curBetColorField;
        private FieldInfo _itemsToBetField;
        private PropertyInfo _curServerSaveProperty;
        private PropertyInfo _vitalsProperty;
        private PropertyInfo _movementProperty;
        private PropertyInfo _cameraProperty;
        private PropertyInfo _blockInputsProperty;
        private PropertyInfo _mouseLockedProperty;
        private PropertyInfo _currentLobbyIdProperty;
        private PropertyInfo _slotAvailableItemsProperty;
        private PropertyInfo _boatProperty;
        private PropertyInfo _itemIdProperty;
        private PropertyInfo _itemSkinPresetProperty;
        private PropertyInfo _boatSkinPresetProperty;
        private PropertyInfo _itemRigProperty;
        private MethodInfo _addMoneyMethod;
        private MethodInfo _toggleGodModeMethod;
        private MethodInfo _getGodModeMethod;
        private MethodInfo _getRandomSkinIndexMethod;
        private MethodInfo _aimAssistCacheSettingsMethod;
        private MethodInfo _itemToggleInteractableMethod;
        private MethodInfo _itemAddBetMultiplierMethod;
        private MethodInfo _itemDestroyMethod;
        private MethodInfo _casinoCalculateWorthMethod;
        private MethodInfo _casinoBetResultEffectsMethod;
        private MethodInfo _casinoSetBettingMethod;

        private object _tunedAimAssistInstance;
        private bool _aimAssistSettingsCaptured;
        private float _originalAimMaxTargetDistance;
        private float _originalAimAcquireAngle;
        private float _originalAimTrackingBreakAngle;
        private float _originalAimTargetScanInterval;
        private float _originalAimMaxRotationSpeed;
        private float _originalAimTrackingSharpness;
        private PropertyInfo _rigVelocityProperty;

        private Harmony _harmony;
        private bool _gameApiReady;
        private bool _apiBindingWarningLogged;
        private bool _patchesInstalled;
        private bool _patchInstallAttempted;
        private bool _combatPatchesInstalled;
        private bool _casinoPatchesInstalled;
        private bool _slotPatchInstalled;
        private bool _aimPatchInstalled;
        private bool _aimLeadPatchInstalled;
        private int _casinoPatchHitCount;
        private int _slotPatchHitCount;
        private int _aimPatchHitCount;
        private int _aimLeadPatchHitCount;

        private object _creatureManagerInstance;
        private int _originalShinyChance;
        private bool _shinyChanceCaptured;

        private object _movementInstance;
        private FieldInfo _walkSpeedField;
        private FieldInfo _sprintSpeedField;
        private FieldInfo _jumpForceField;
        private float _originalWalkSpeed;
        private float _originalSprintSpeed;
        private float _originalJumpForce;
        private bool _movementCaptured;

        private Camera _cameraInstance;
        private float _originalCameraFov;
        private bool _cameraFovCaptured;

        private GUIStyle _titleStyle;
        private GUIStyle _statusStyle;
        private GUIStyle _smallStyle;

        private void Awake()
        {
            _instance = this;
            _panelKey = Config.Bind("Hotkeys", "TogglePanel", new KeyboardShortcut(KeyCode.Insert), "显示或隐藏修改器面板");
            _addMoneyKey = Config.Bind("Hotkeys", "AddMoney", new KeyboardShortcut(KeyCode.F1), "增加 9999 金钱（仅离线）");
            _godModeKey = Config.Bind("Hotkeys", "ToggleGodMode", new KeyboardShortcut(KeyCode.F2), "切换无敌（仅离线）");
            _fullnessKey = Config.Bind("Hotkeys", "ToggleFullnessLock", new KeyboardShortcut(KeyCode.F3), "切换饱食锁定（仅离线）");
            _speedKey = Config.Bind("Hotkeys", "CycleMoveSpeed", new KeyboardShortcut(KeyCode.F4), "循环移动倍率 1x/2x/3x/5x（仅离线）");
            _jumpKey = Config.Bind("Hotkeys", "CycleJump", new KeyboardShortcut(KeyCode.F5), "循环跳跃倍率 1x/2x/3x/5x（仅离线）");
            _damageKey = Config.Bind("Hotkeys", "CycleDamage", new KeyboardShortcut(KeyCode.F6), "循环伤害倍率 1x/2x/3x/5x/10x（仅离线）");
            _healthKey = Config.Bind("Hotkeys", "CycleHealth", new KeyboardShortcut(KeyCode.F7), "循环等效血量倍率 1x/2x/3x/5x/10x（仅离线）");
            _shinyKey = Config.Bind("Hotkeys", "CycleShinyChance", new KeyboardShortcut(KeyCode.F8), "循环极品动物概率：关闭/10%/25%/50%/100%（仅离线）");
            _gambleKey = Config.Bind("Hotkeys", "CycleGambleWinChance", new KeyboardShortcut(KeyCode.F9), "循环赌博轮盘胜率：关闭/25%/50%/75%/100%（仅离线）");
            _slotRarityKey = Config.Bind("Hotkeys", "CycleSlotSkinRarity", new KeyboardShortcut(KeyCode.F10), "循环鱼转盘皮肤品质：关闭/普通/稀有/传奇（仅离线）");
            _fovKey = Config.Bind("Hotkeys", "CycleCameraFov", new KeyboardShortcut(KeyCode.F11), "循环本地镜头 FOV：默认/75/90/105/120（联机可用）");
            _fpsOverlayKey = Config.Bind("Hotkeys", "ToggleFpsOverlay", new KeyboardShortcut(KeyCode.Home), "显示或隐藏本地 FPS/帧耗时（联机可用）");
            _aimAssistKey = Config.Bind("Hotkeys", "ToggleAimAssistRightCtrl", new KeyboardShortcut(KeyCode.RightControl), "切换武器瞄准辅助（单人或房主开启的好友邀请房）");
            _disableKey = Config.Bind("Hotkeys", "DisableAll", new KeyboardShortcut(KeyCode.End), "关闭并还原全部功能");

            _gameApiReady = ResolveGameApi();
            if (_gameApiReady)
                InstallHarmonyPatches();
            Logger.LogInfo(PluginName + " " + PluginVersion + " loaded. Private-room consent guard and offline gameplay guard are enabled.");
        }

        private void Update()
        {
            UpdateFrameStats();

            if (_panelKey.Value.IsDown())
                _showPanel = !_showPanel;

            if (_disableKey.Value.IsDown())
            {
                DisableAllFeatures("已关闭并还原全部功能");
                return;
            }

            if (_fovKey.Value.IsDown())
                CycleCameraFov();

            if (_fpsOverlayKey.Value.IsDown())
            {
                _fpsOverlayEnabled = !_fpsOverlayEnabled;
                _lastAction = _fpsOverlayEnabled ? "FPS/帧耗时显示：开启" : "FPS/帧耗时显示：关闭";
            }

            ApplyCameraFov();

            if (!EnsureGameApi())
                return;

            bool online = IsExplicitlyMultiplayer();
            bool privateInviteHost = online && IsPrivateInviteHostRoom();

            if (online)
            {
                if (privateInviteHost)
                    UpdatePrivateRoomSession();
                else
                    ResetPrivateRoomSession();

                if (_aimAssistKey.Value.IsDown())
                    ToggleAimAssist();

                if (!_onlineModeActive)
                    DisableOfflineFeatures(privateInviteHost
                        ? "好友邀请房：确认已获全员同意后可开启瞄准辅助"
                        : "联机模式：仅本地显示功能可用");
                _onlineModeActive = true;

                if (_aimAssistEnabled && !privateInviteHost)
                    SetAimAssistEnabled(false, false, "当前不是由本机主持的好友邀请房，瞄准辅助已关闭");
                return;
            }

            if (_onlineModeActive && _aimAssistEnabled)
                SetAimAssistEnabled(false, false, "已离开好友房，瞄准辅助已关闭；单人模式可重新开启");
            _onlineModeActive = false;
            ResetPrivateRoomSession();

            if (_aimAssistKey.Value.IsDown())
                ToggleAimAssist();

            object player;
            string reason;
            bool safe = TryGetOfflinePlayer(out player, out reason);

            if (!safe)
                return;

            if (_addMoneyKey.Value.IsDown())
                AddMoney(player);

            if (_godModeKey.Value.IsDown())
                ToggleGodMode();

            if (_fullnessKey.Value.IsDown())
            {
                _fullnessLock = !_fullnessLock;
                _lastAction = _fullnessLock ? "饱食锁定：开启" : "饱食锁定：关闭";
            }

            if (_speedKey.Value.IsDown())
            {
                _moveMultiplier = NextMultiplier(_moveMultiplier);
                _lastAction = "移动倍率：" + _moveMultiplier.ToString("0.##") + "x";
            }

            if (_jumpKey.Value.IsDown())
            {
                _jumpMultiplier = NextMultiplier(_jumpMultiplier);
                _lastAction = "跳跃倍率：" + _jumpMultiplier.ToString("0.##") + "x";
            }

            if (_damageKey.Value.IsDown())
            {
                _damageMultiplier = NextCombatMultiplier(_damageMultiplier);
                _lastAction = "伤害倍率：" + _damageMultiplier.ToString("0.##") + "x";
            }

            if (_healthKey.Value.IsDown())
            {
                _healthMultiplier = NextCombatMultiplier(_healthMultiplier);
                _lastAction = "等效血量倍率：" + _healthMultiplier.ToString("0.##") + "x";
            }

            if (_shinyKey.Value.IsDown())
            {
                CycleShinyChance();
            }

            if (_gambleKey.Value.IsDown())
            {
                CycleGambleChance();
            }

            if (_slotRarityKey.Value.IsDown())
            {
                CycleSlotRarity();
            }

            if (_fullnessLock && Time.unscaledTime >= _nextVitalsUpdate)
            {
                _nextVitalsUpdate = Time.unscaledTime + 0.5f;
                RestoreVitals(player);
            }

            ApplyMovement(player);
            ApplyShinyChance();
        }

        private void OnGUI()
        {
            EnsureStyles();

            if (_fpsOverlayEnabled)
            {
                float frameMs = _smoothedFrameTime * 1000f;
                float fps = 1f / Mathf.Max(0.0001f, _smoothedFrameTime);
                GUI.Box(
                    new Rect(Mathf.Max(8f, Screen.width - 190f), 18f, 172f, 46f),
                    "FPS  " + fps.ToString("0") + "\n帧耗时  " + frameMs.ToString("0.0") + " ms");
            }

            if (_showPanel)
                _window = GUILayout.Window(381457, _window, DrawWindow, "How to Fish 修改器");
        }

        private void DrawWindow(int windowId)
        {
            object player = null;
            string reason = "游戏接口尚未就绪";
            bool apiReady = EnsureGameApi();
            bool online = apiReady && IsExplicitlyMultiplayer();
            bool privateInviteHost = online && IsPrivateInviteHostRoom();
            bool safe = apiReady && !online && TryGetOfflinePlayer(out player, out reason);

            GUILayout.Label("进程内模组 · v" + PluginVersion, _titleStyle);
            GUI.color = safe
                ? new Color(0.55f, 1f, 0.55f)
                : privateInviteHost ? new Color(0.75f, 0.65f, 1f)
                : online ? new Color(0.45f, 0.85f, 1f) : new Color(1f, 0.72f, 0.35f);
            GUILayout.Label(
                safe
                    ? "状态：单人存档 — 全部功能可用"
                    : privateInviteHost ? "状态：好友邀请房（本机房主）— 确认同意后可用瞄准辅助"
                    : online ? "状态：联机模式 — 仅本地显示功能可用" : "状态：等待 — " + reason,
                _statusStyle);
            GUI.color = Color.white;

            GUILayout.Space(6f);
            _scrollPosition = GUILayout.BeginScrollView(
                _scrollPosition,
                GUILayout.Height(Mathf.Max(320f, Mathf.Min(620f, _window.height - 92f))));

            GUI.enabled = true;
            GUI.color = new Color(0.45f, 0.85f, 1f);
            GUILayout.Label("联机可用 · 仅影响本机显示", _statusStyle);
            GUI.color = Color.white;

            bool newFpsOverlay = GUILayout.Toggle(_fpsOverlayEnabled, "Home  显示 FPS 与帧耗时");
            if (newFpsOverlay != _fpsOverlayEnabled)
            {
                _fpsOverlayEnabled = newFpsOverlay;
                _lastAction = _fpsOverlayEnabled ? "FPS/帧耗时显示：开启" : "FPS/帧耗时显示：关闭";
            }

            bool newFovOverride = GUILayout.Toggle(_fovOverrideEnabled,
                "F11  本地镜头 FOV：" + (_fovOverrideEnabled ? _cameraFov.ToString("0") : "游戏默认"));
            if (newFovOverride != _fovOverrideEnabled)
            {
                _fovOverrideEnabled = newFovOverride;
                _lastAction = _fovOverrideEnabled ? "本地镜头 FOV：" + _cameraFov.ToString("0") : "本地镜头 FOV：恢复游戏默认";
                if (!_fovOverrideEnabled)
                    RestoreCameraFov();
            }

            GUI.enabled = _fovOverrideEnabled;
            float newCameraFov = Mathf.Round(GUILayout.HorizontalSlider(_cameraFov, 55f, 120f));
            if (GUI.enabled && Math.Abs(newCameraFov - _cameraFov) > 0.001f)
                _cameraFov = newCameraFov;

            GUI.enabled = true;
            GUILayout.Label("以上功能不修改网络数据、角色数值、物品或服务器结算。", _smallStyle);
            GUILayout.Space(8f);

            GUI.color = new Color(0.75f, 0.65f, 1f);
            GUILayout.Label("单人 / 好友邀请房房主可用", _statusStyle);
            GUI.color = Color.white;

            GUI.enabled = privateInviteHost;
            bool newConsent = GUILayout.Toggle(
                _consentConfirmedForLobby,
                "我已获得当前房间内所有成员同意");
            if (newConsent != _consentConfirmedForLobby && GUI.enabled)
            {
                _consentConfirmedForLobby = newConsent;
                if (!newConsent && _aimAssistEnabled)
                    SetAimAssistEnabled(false, false, "已撤销同意确认，武器瞄准辅助已关闭");
                else
                    _lastAction = newConsent ? "已确认获得当前房间全员同意" : "已撤销房间同意确认";
            }

            bool aimControlsAvailable = safe || (privateInviteHost && _consentConfirmedForLobby);
            GUI.enabled = aimControlsAvailable;
            bool newAimAssist = GUILayout.Toggle(_aimAssistEnabled, "右 Ctrl  武器瞄准辅助（举枪瞄准时）");
            if (newAimAssist != _aimAssistEnabled && GUI.enabled)
                SetAimAssistEnabled(newAimAssist, true, newAimAssist ? "武器瞄准辅助：开启" : "武器瞄准辅助：关闭");

            GUILayout.Label("自瞄跟随速度：" + _aimAssistSpeedMultiplier.ToString("0.00") + "x");
            float newAimSpeed = RoundQuarter(GUILayout.HorizontalSlider(_aimAssistSpeedMultiplier, 1f, 12f));
            if (aimControlsAvailable && Math.Abs(newAimSpeed - _aimAssistSpeedMultiplier) > 0.001f)
            {
                _aimAssistSpeedMultiplier = newAimSpeed;
                _lastAction = "自瞄跟随速度：" + _aimAssistSpeedMultiplier.ToString("0.00") + "x";
            }

            GUILayout.Label("自瞄锁定角度：" + _aimAssistAcquireAngle.ToString("0") + "°");
            float newAimAngle = Mathf.Round(GUILayout.HorizontalSlider(_aimAssistAcquireAngle, 5f, 60f));
            if (aimControlsAvailable && Math.Abs(newAimAngle - _aimAssistAcquireAngle) > 0.001f)
            {
                _aimAssistAcquireAngle = newAimAngle;
                _lastAction = "自瞄锁定角度：" + _aimAssistAcquireAngle.ToString("0") + "°";
            }

            GUILayout.Label("移动目标前置：" + _aimAssistLeadSeconds.ToString("0.00") + " 秒");
            float newAimLead = Mathf.Round(GUILayout.HorizontalSlider(_aimAssistLeadSeconds, 0f, 0.5f) * 100f) / 100f;
            if (aimControlsAvailable && Math.Abs(newAimLead - _aimAssistLeadSeconds) > 0.001f)
            {
                _aimAssistLeadSeconds = newAimLead;
                _lastAction = "移动目标前置：" + _aimAssistLeadSeconds.ToString("0.00") + " 秒";
            }

            GUI.enabled = true;
            GUILayout.Label("速度越高跟枪越快；快速横移目标可适当提高前置量。好友房须先勾选同意确认。", _smallStyle);

            GUILayout.Space(8f);
            GUILayout.Label("仅单人存档可用", _statusStyle);
            GUI.enabled = safe;

            if (GUILayout.Button("F1  增加 9999 金钱", GUILayout.Height(30f)) && safe)
                AddMoney(player);

            bool godMode = GetGodMode();
            if (GUILayout.Button("F2  无敌：" + (godMode ? "开启" : "关闭"), GUILayout.Height(30f)) && safe)
                ToggleGodMode();

            bool newFullnessLock = GUILayout.Toggle(_fullnessLock, "F3  饱食锁定");
            if (newFullnessLock != _fullnessLock && safe)
            {
                _fullnessLock = newFullnessLock;
                _lastAction = _fullnessLock ? "饱食锁定：开启" : "饱食锁定：关闭";
            }

            GUILayout.Space(5f);
            GUILayout.Label("F4  移动倍率：" + _moveMultiplier.ToString("0.00") + "x");
            float newMove = RoundQuarter(GUILayout.HorizontalSlider(_moveMultiplier, 1f, 5f));
            if (safe && Math.Abs(newMove - _moveMultiplier) > 0.001f)
                _moveMultiplier = newMove;

            GUILayout.Label("F5  跳跃倍率：" + _jumpMultiplier.ToString("0.00") + "x");
            float newJump = RoundQuarter(GUILayout.HorizontalSlider(_jumpMultiplier, 1f, 5f));
            if (safe && Math.Abs(newJump - _jumpMultiplier) > 0.001f)
                _jumpMultiplier = newJump;

            GUILayout.Space(7f);
            GUILayout.Label("F6  对动物伤害倍率：" + _damageMultiplier.ToString("0.00") + "x");
            float newDamage = RoundQuarter(GUILayout.HorizontalSlider(_damageMultiplier, 1f, 10f));
            if (safe && Math.Abs(newDamage - _damageMultiplier) > 0.001f)
                _damageMultiplier = newDamage;

            GUILayout.Label("F7  等效血量倍率：" + _healthMultiplier.ToString("0.00") + "x");
            float newHealth = RoundQuarter(GUILayout.HorizontalSlider(_healthMultiplier, 1f, 10f));
            if (safe && Math.Abs(newHealth - _healthMultiplier) > 0.001f)
                _healthMultiplier = newHealth;

            bool newShinyOverride = GUILayout.Toggle(_shinyOverrideEnabled,
                "F8  覆盖极品动物概率：" + (_shinyOverrideEnabled ? _shinyChance + "%" : "关闭（游戏默认）"));
            if (newShinyOverride != _shinyOverrideEnabled && safe)
            {
                _shinyOverrideEnabled = newShinyOverride;
                _lastAction = _shinyOverrideEnabled ? "极品动物概率：" + _shinyChance + "%" : "极品动物概率：恢复游戏默认";
                if (!_shinyOverrideEnabled)
                    RestoreShinyChance();
            }

            GUI.enabled = safe && _shinyOverrideEnabled;
            int newShinyChance = Mathf.RoundToInt(GUILayout.HorizontalSlider(_shinyChance, 1f, 100f));
            if (GUI.enabled && newShinyChance != _shinyChance)
                _shinyChance = newShinyChance;

            GUI.enabled = safe;
            GUILayout.Label("血量倍率通过缩放承伤实现，血条和存档仍保持原生 100 点结构。", _smallStyle);

            GUILayout.Space(7f);
            bool newGambleOverride = GUILayout.Toggle(_gambleOverrideEnabled,
                "F9  覆盖赌博轮盘胜率：" + (_gambleOverrideEnabled ? _gambleWinChance + "%" : "关闭（游戏默认）"));
            if (newGambleOverride != _gambleOverrideEnabled && safe)
            {
                _gambleOverrideEnabled = newGambleOverride;
                _lastAction = _gambleOverrideEnabled ? "赌博轮盘胜率：" + _gambleWinChance + "%" : "赌博轮盘胜率：恢复游戏默认";
            }

            GUI.enabled = safe && _gambleOverrideEnabled;
            int newGambleChance = Mathf.RoundToInt(GUILayout.HorizontalSlider(_gambleWinChance, 0f, 100f));
            if (GUI.enabled && newGambleChance != _gambleWinChance)
                _gambleWinChance = newGambleChance;
            GUILayout.Label("覆盖最终输赢与赔付；转盘小球的物理动画仍由游戏运行。", _smallStyle);

            GUI.enabled = safe;
            bool newSlotRarityOverride = GUILayout.Toggle(_slotRarityOverrideEnabled,
                "F10 鱼转盘皮肤品质：" + (_slotRarityOverrideEnabled ? RarityName(_slotRarity) : "关闭（游戏默认）"));
            if (newSlotRarityOverride != _slotRarityOverrideEnabled && safe)
            {
                _slotRarityOverrideEnabled = newSlotRarityOverride;
                _lastAction = _slotRarityOverrideEnabled
                    ? "鱼转盘皮肤品质：" + RarityName(_slotRarity)
                    : "鱼转盘皮肤品质：恢复游戏默认";
            }

            GUI.enabled = safe && _slotRarityOverrideEnabled;
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("普通")) SetSlotRarity(1);
            if (GUILayout.Button("稀有")) SetSlotRarity(2);
            if (GUILayout.Button("传奇")) SetSlotRarity(3);
            GUILayout.EndHorizontal();
            GUILayout.Label("直接锁定鱼转盘最终获奖格的皮肤品质，不修改普通掉落。", _smallStyle);

            GUI.enabled = true;
            GUILayout.Space(8f);
            if (GUILayout.Button("End  关闭并还原全部功能", GUILayout.Height(28f)))
                DisableAllFeatures("已关闭并还原全部功能");

            GUILayout.Space(5f);
            GUILayout.Label("Insert 隐藏/显示面板", _smallStyle);
            string aimPatchState = _aimPatchInstalled
                ? (_aimLeadPatchInstalled ? "正常" : "基础可用/前置失败")
                : "失败";
            GUILayout.Label(
                "补丁状态：自瞄=" + aimPatchState +
                "　赌博=" + (_casinoPatchesInstalled ? "正常" : "失败") +
                "　鱼转盘=" + (_slotPatchInstalled ? "正常" : "失败"),
                _smallStyle);
            GUILayout.Label(
                "运行命中：自瞄=" + _aimPatchHitCount +
                "　前置=" + _aimLeadPatchHitCount +
                "　赌博结算=" + _casinoPatchHitCount +
                "　鱼转盘=" + _slotPatchHitCount,
                _smallStyle);
            GUILayout.Label("最近操作：" + _lastAction, _smallStyle);
            GUILayout.Label("公开房间或非房主客户端会自动关闭瞄准辅助；其他单人功能显示为灰色。", _smallStyle);
            GUILayout.EndScrollView();
            GUI.DragWindow(new Rect(0f, 0f, 10000f, 28f));
        }

        private bool EnsureGameApi()
        {
            if (_gameApiReady)
            {
                if (!_patchInstallAttempted)
                    InstallHarmonyPatches();
                return true;
            }

            if (Time.unscaledTime < _nextResolveAttempt)
                return false;

            _nextResolveAttempt = Time.unscaledTime + 2f;
            _gameApiReady = ResolveGameApi();
            if (_gameApiReady)
                InstallHarmonyPatches();
            return _gameApiReady;
        }

        private bool ResolveGameApi()
        {
            try
            {
                _gameAssembly = AppDomain.CurrentDomain.GetAssemblies()
                    .FirstOrDefault(a => string.Equals(a.GetName().Name, "Assembly-CSharp", StringComparison.Ordinal));
                if (_gameAssembly == null)
                    return false;

                _playerType = _gameAssembly.GetType("Player", false);
                _moneyManagerType = _gameAssembly.GetType("MoneyManager", false);
                _playerManagerType = _gameAssembly.GetType("PlayerManager", false);
                _saveManagerType = _gameAssembly.GetType("SaveManager", false);
                _connectionManagerType = _gameAssembly.GetType("ConnectionManager", false);
                _creatureManagerType = _gameAssembly.GetType("CreatureManager", false);
                _creatureType = _gameAssembly.GetType("Creature", false);
                _serverType = _gameAssembly.GetType("Server", false);
                _playerVitalsType = _gameAssembly.GetType("PlayerVitals", false);
                _casinoManagerType = _gameAssembly.GetType("CasinoManager", false);
                _slotMachineManagerType = _gameAssembly.GetType("SlotMachineManager", false);
                _slotMachineType = _gameAssembly.GetType("SlotMachine", false);
                _skinPresetType = _gameAssembly.GetType("SkinPreset", false);
                _itemType = _gameAssembly.GetType("Item", false);
                _boatManagerType = _gameAssembly.GetType("BoatManager", false);
                _boatType = _gameAssembly.GetType("Boat", false);
                _betColorType = _gameAssembly.GetType("BetColor", false);
                _rarityType = _gameAssembly.GetType("Rarity", false);
                _playerAimAssistType = _gameAssembly.GetType("PlayerAimAssist", false);
                _steamManagerType = _gameAssembly.GetType("SteamManager", false);

                if (_playerType == null || _moneyManagerType == null || _playerManagerType == null ||
                    _saveManagerType == null || _connectionManagerType == null || _creatureManagerType == null ||
                    _creatureType == null || _serverType == null || _playerVitalsType == null ||
                    _casinoManagerType == null || _slotMachineManagerType == null || _slotMachineType == null ||
                    _skinPresetType == null || _itemType == null || _boatManagerType == null || _boatType == null ||
                    _betColorType == null || _rarityType == null || _playerAimAssistType == null ||
                    _steamManagerType == null)
                    return false;

                _currentLobbyIdProperty = _steamManagerType.GetProperty("CurrentLobbyID", AnyStatic);
                if (_currentLobbyIdProperty == null)
                    return false;

                _localPlayerField = _playerType.GetField("LocalPlayer", AnyStatic);
                _isUsingSteamField = _connectionManagerType.GetField("IsUsingSteam", AnyStatic);
                _connectionManagerInstanceField = _connectionManagerType.GetField("Instance", AnyStatic);
                _networkManagerField = _connectionManagerType.GetField("_netMan", AnyInstance);
                _aimAssistPlayerField = _playerAimAssistType.GetField("_player", AnyInstance);
                _aimAssistMaxTargetDistanceField = _playerAimAssistType.GetField("_maxTargetDistance", AnyInstance);
                _aimAssistAcquireAngleField = _playerAimAssistType.GetField("_adsAcquireAngle", AnyInstance);
                _aimAssistTrackingBreakAngleField = _playerAimAssistType.GetField("_trackingBreakAngle", AnyInstance);
                _aimAssistTargetScanIntervalField = _playerAimAssistType.GetField("_targetScanInterval", AnyInstance);
                _aimAssistMaxRotationSpeedField = _playerAimAssistType.GetField("_maxRotationSpeed", AnyInstance);
                _aimAssistTrackingSharpnessField = _playerAimAssistType.GetField("_trackingSharpness", AnyInstance);
                _creatureManagerInstanceField = _creatureManagerType.GetField("Instance", AnyStatic);
                _shinyCreatureChanceField = _creatureManagerType.GetField("_shinyCreatureChance", AnyInstance);
                _curBetColorField = _casinoManagerType.GetField("_curBetColor", AnyStatic);
                _itemsToBetField = _casinoManagerType.GetField("_itemsToBet", AnyStatic);
                _curServerSaveProperty = _saveManagerType.GetProperty("CurServerSave", AnyStatic);
                _vitalsProperty = _playerType.GetProperty("Vitals", AnyInstance);
                _movementProperty = _playerType.GetProperty("Movement", AnyInstance);
                _cameraProperty = _playerType.GetProperty("Camera", AnyInstance);
                _blockInputsProperty = _playerType.GetProperty("BlockInputs", AnyInstance);
                _itemRigProperty = _itemType.GetProperty("Rig", AnyInstance);
                _itemIdProperty = _itemType.GetProperty("ID", AnyInstance);
                _itemSkinPresetProperty = _itemType.GetProperty("SkinPreset", AnyInstance);
                _slotAvailableItemsProperty = _slotMachineType.GetProperty("AvailableItems", AnyStatic);
                _boatProperty = _boatManagerType.GetProperty("Boat", AnyStatic);
                _boatSkinPresetProperty = _boatType.GetProperty("SkinPreset", AnyInstance);
                if (_cameraProperty != null)
                    _mouseLockedProperty = _cameraProperty.PropertyType.GetProperty("MouseLocked", AnyInstance);
                _addMoneyMethod = _moneyManagerType.GetMethod(
                    "AddMoney", AnyStatic, null, new[] { typeof(int), _playerType }, null);
                _toggleGodModeMethod = _playerManagerType.GetMethod("ToggleGodMode", AnyStatic, null, Type.EmptyTypes, null);
                _getGodModeMethod = _playerManagerType.GetMethod("get_InGodMode", AnyStatic, null, Type.EmptyTypes, null);
                _getRandomSkinIndexMethod = _skinPresetType.GetMethod(
                    "GetRandomSkinIndex", AnyInstance | AnyStatic, null, new[] { _rarityType }, null);
                _aimAssistCacheSettingsMethod = _playerAimAssistType.GetMethod(
                    "CacheSettings", AnyInstance, null, Type.EmptyTypes, null);
                _itemToggleInteractableMethod = _itemType.GetMethod(
                    "ToggleInteractable", AnyInstance, null, new[] { typeof(bool) }, null);
                _itemAddBetMultiplierMethod = _itemType.GetMethod(
                    "AddBetMultiplier", AnyInstance, null, new[] { typeof(float) }, null);
                _itemDestroyMethod = _itemType.GetMethod(
                    "DestroyItem", AnyInstance, null, new[] { typeof(byte), typeof(byte) }, null);
                _casinoCalculateWorthMethod = _casinoManagerType.GetMethod(
                    "CalculateWorth", AnyStatic, null, new[] { typeof(bool) }, null);
                _casinoBetResultEffectsMethod = _casinoManagerType.GetMethod(
                    "BetResultEffects", AnyInstance, null, new[] { typeof(byte), typeof(bool) }, null);
                _casinoSetBettingMethod = _casinoManagerType.GetMethod(
                    "set_IsBetting", AnyStatic, null, new[] { typeof(bool) }, null);

                bool ready = _localPlayerField != null && _isUsingSteamField != null &&
                    _connectionManagerInstanceField != null && _networkManagerField != null &&
                    _aimAssistPlayerField != null && _aimAssistMaxTargetDistanceField != null &&
                    _aimAssistAcquireAngleField != null && _aimAssistTrackingBreakAngleField != null &&
                    _aimAssistTargetScanIntervalField != null && _aimAssistMaxRotationSpeedField != null &&
                    _aimAssistTrackingSharpnessField != null &&
                    _creatureManagerInstanceField != null && _shinyCreatureChanceField != null &&
                    _curBetColorField != null && _itemsToBetField != null &&
                    _curServerSaveProperty != null && _vitalsProperty != null && _movementProperty != null &&
                    _cameraProperty != null && _blockInputsProperty != null && _mouseLockedProperty != null &&
                    _itemRigProperty != null && _itemIdProperty != null && _itemSkinPresetProperty != null &&
                    _slotAvailableItemsProperty != null && _boatProperty != null && _boatSkinPresetProperty != null &&
                    _addMoneyMethod != null && _toggleGodModeMethod != null && _getGodModeMethod != null &&
                    _getRandomSkinIndexMethod != null && _aimAssistCacheSettingsMethod != null &&
                    _itemToggleInteractableMethod != null && _itemAddBetMultiplierMethod != null &&
                    _itemDestroyMethod != null && _casinoCalculateWorthMethod != null &&
                    _casinoBetResultEffectsMethod != null && _casinoSetBettingMethod != null;
                if (!ready && !_apiBindingWarningLogged)
                {
                    _apiBindingWarningLogged = true;
                    string[] missing = new[]
                    {
                        _localPlayerField == null ? "Player.LocalPlayer" : null,
                        _isUsingSteamField == null ? "ConnectionManager.IsUsingSteam" : null,
                        _aimAssistPlayerField == null ? "PlayerAimAssist._player" : null,
                        _aimAssistMaxRotationSpeedField == null ? "PlayerAimAssist._maxRotationSpeed" : null,
                        _aimAssistTrackingSharpnessField == null ? "PlayerAimAssist._trackingSharpness" : null,
                        _curBetColorField == null ? "CasinoManager._curBetColor" : null,
                        _itemsToBetField == null ? "CasinoManager._itemsToBet" : null,
                        _slotAvailableItemsProperty == null ? "SlotMachine.AvailableItems" : null,
                        _getRandomSkinIndexMethod == null ? "SkinPreset.GetRandomSkinIndex" : null,
                        _casinoCalculateWorthMethod == null ? "CasinoManager.CalculateWorth" : null,
                        _casinoBetResultEffectsMethod == null ? "CasinoManager.BetResultEffects" : null,
                        _casinoSetBettingMethod == null ? "CasinoManager.set_IsBetting" : null
                    }.Where(name => name != null).ToArray();
                    Logger.LogWarning("Game API bindings missing: " + string.Join(", ", missing));
                }
                return ready;
            }
            catch (Exception ex)
            {
                Logger.LogWarning("Could not resolve game API: " + ex.Message);
                return false;
            }
        }

        private void InstallHarmonyPatches()
        {
            if (_patchInstallAttempted)
                return;
            _patchInstallAttempted = true;

            if (_serverType == null || _playerVitalsType == null || _casinoManagerType == null ||
                _slotMachineManagerType == null || _playerAimAssistType == null)
            {
                Logger.LogWarning("Patch installation skipped: required game types were not resolved.");
                return;
            }

            _harmony = new Harmony(PluginGuid);

            MethodInfo hitCreature = _serverType.GetMethod(
                "HitCreature", AnyInstance, null,
                new[] { _creatureType, _playerType, typeof(int), typeof(Vector3), typeof(Vector3) }, null);
            MethodInfo takeDamage = _playerVitalsType.GetMethod(
                "TakeDamage", AnyInstance, null,
                new[] { typeof(int), typeof(Vector3), typeof(Vector3), typeof(bool) }, null);
            MethodInfo rouletteResult = _casinoManagerType.GetMethod(
                "ServerRouletteResult", AnyInstance | AnyStatic, null, new[] { _betColorType }, null);
            MethodInfo rouletteStart = _casinoManagerType.GetMethod(
                "ServerStartBet", AnyInstance | AnyStatic, null, new[] { _betColorType }, null);
            MethodInfo sendRoll = _slotMachineManagerType.GetMethod(
                "SendRoll", AnyInstance, null,
                new[] { _playerType, typeof(byte[]), typeof(byte[]), typeof(byte) }, null);
            MethodInfo canUseAimAssist = _playerAimAssistType.GetMethod(
                "CanUseAimAssist", AnyInstance, null, Type.EmptyTypes, null);
            MethodInfo getAimTargetPosition = _playerAimAssistType.GetMethod(
                "GetTargetPosition", AnyStatic, null, new[] { _creatureType }, null);

            Type patchType = typeof(TrainerPlugin);
            bool hitInstalled = TryInstallPatch(
                "伤害倍率", hitCreature, patchType.GetMethod("HitCreaturePrefix", AnyStatic), null);
            bool healthInstalled = TryInstallPatch(
                "血量倍率", takeDamage, patchType.GetMethod("PlayerTakeDamagePrefix", AnyStatic), null);
            _combatPatchesInstalled = hitInstalled && healthInstalled;

            bool rouletteStartInstalled = TryInstallPatch(
                "赌博下注捕获", rouletteStart, patchType.GetMethod("RouletteStartPrefix", AnyStatic), null);
            bool rouletteResultInstalled = TryInstallPatch(
                "赌博最终结算", rouletteResult, patchType.GetMethod("RouletteResultPrefix", AnyStatic), null);
            _casinoPatchesInstalled = rouletteStartInstalled && rouletteResultInstalled;

            _slotPatchInstalled = TryInstallPatch(
                "鱼转盘最终奖励", sendRoll, patchType.GetMethod("SlotResultPrefix", AnyStatic), null);
            _aimPatchInstalled = TryInstallPatch(
                "自瞄启用", canUseAimAssist, null, patchType.GetMethod("AimAssistCanUsePostfix", AnyStatic));
            _aimLeadPatchInstalled = TryInstallPatch(
                "自瞄目标前置", getAimTargetPosition, null, patchType.GetMethod("AimTargetPositionPostfix", AnyStatic));

            _patchesInstalled = hitInstalled || healthInstalled || _casinoPatchesInstalled ||
                _slotPatchInstalled || _aimPatchInstalled || _aimLeadPatchInstalled;
            Logger.LogInfo(
                "Patch summary: combat=" + _combatPatchesInstalled +
                ", casino=" + _casinoPatchesInstalled +
                ", slot=" + _slotPatchInstalled +
                ", aim=" + _aimPatchInstalled +
                ", aimLead=" + _aimLeadPatchInstalled + ".");
        }

        private bool TryInstallPatch(
            string label,
            MethodInfo original,
            MethodInfo prefix,
            MethodInfo postfix)
        {
            if (original == null)
            {
                Logger.LogWarning(label + "补丁未安装：找不到游戏目标函数。");
                return false;
            }
            if (prefix == null && postfix == null)
            {
                Logger.LogWarning(label + "补丁未安装：找不到补丁函数。");
                return false;
            }

            try
            {
                _harmony.Patch(
                    original,
                    prefix == null ? null : new HarmonyMethod(prefix),
                    postfix == null ? null : new HarmonyMethod(postfix));
                Logger.LogInfo(label + "补丁：已安装。");
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogWarning(label + "补丁安装失败：" + ex.Message);
                return false;
            }
        }

        private static void HitCreaturePrefix(ref int damage)
        {
            TrainerPlugin plugin = _instance;
            if (plugin == null || plugin._damageMultiplier <= 1.001f || !plugin.CanApplyPatchedEffect(null))
                return;

            if (damage <= 0)
                return;

            double scaled = Math.Round(damage * (double)plugin._damageMultiplier, MidpointRounding.AwayFromZero);
            damage = (int)Math.Min(int.MaxValue, Math.Max(1d, scaled));
        }

        private static void PlayerTakeDamagePrefix(object __instance, ref int amount)
        {
            TrainerPlugin plugin = _instance;
            if (plugin == null || plugin._healthMultiplier <= 1.001f || !plugin.CanApplyPatchedEffect(__instance))
                return;

            double absoluteAmount = Math.Abs((double)amount);
            if (absoluteAmount < 1d)
                return;

            double scaled = Math.Ceiling(absoluteAmount / plugin._healthMultiplier);
            amount = (int)Math.Min(int.MaxValue, Math.Max(1d, scaled));
        }

        private static void RouletteStartPrefix(object[] __args)
        {
            TrainerPlugin plugin = _instance;
            if (plugin == null || __args == null || __args.Length == 0 || !plugin.CanApplyPatchedEffect(null))
                return;

            plugin._lastSelectedBetColor = __args[0];
        }

        private static bool RouletteResultPrefix(object __instance, object[] __args)
        {
            TrainerPlugin plugin = _instance;
            if (plugin == null || !plugin._gambleOverrideEnabled || __args == null || __args.Length == 0 ||
                !plugin.CanApplyPatchedEffect(null))
                return true;

            try
            {
                object selectedColor = plugin._lastSelectedBetColor ?? plugin._curBetColorField.GetValue(null);
                bool forceWin = UnityEngine.Random.Range(0, 100) < Mathf.Clamp(plugin._gambleWinChance, 0, 100);

                int multiplier = 0;
                if (forceWin)
                {
                    int colorValue = Convert.ToInt32(selectedColor);
                    multiplier = colorValue == 2 ? 35 : 2;
                }

                System.Collections.IEnumerable betItems =
                    plugin._itemsToBetField.GetValue(null) as System.Collections.IEnumerable;
                if (betItems == null)
                    return true;

                foreach (object item in betItems)
                {
                    if (item == null)
                        continue;

                    if (forceWin)
                    {
                        plugin._itemToggleInteractableMethod.Invoke(item, new object[] { true });
                        plugin._itemAddBetMultiplierMethod.Invoke(item, new object[] { (float)multiplier });
                    }
                    else
                    {
                        plugin._itemDestroyMethod.Invoke(item, new object[] { (byte)0, byte.MaxValue });
                    }
                }

                plugin._casinoCalculateWorthMethod.Invoke(null, new object[] { forceWin });
                plugin._casinoBetResultEffectsMethod.Invoke(
                    __instance, new object[] { Convert.ToByte(selectedColor), forceWin });
                plugin._casinoSetBettingMethod.Invoke(null, new object[] { false });
                plugin._lastSelectedBetColor = null;
                plugin._casinoPatchHitCount++;
                plugin._lastAction = forceWin
                    ? "赌博最终结算已覆盖：获胜"
                    : "赌博最终结算已覆盖：未获胜";
                return false;
            }
            catch (Exception ex)
            {
                plugin.Logger.LogWarning("Roulette result override failed: " + ex.Message);
                return true;
            }
        }

        private static void SlotResultPrefix(object[] __args)
        {
            TrainerPlugin plugin = _instance;
            if (plugin == null || !plugin._slotRarityOverrideEnabled || __args == null || __args.Length < 4 ||
                !plugin.CanApplyPatchedEffect(null))
                return;

            try
            {
                plugin._slotPatchHitCount++;
                byte[] itemIds = __args[1] as byte[];
                byte[] skinIndices = __args[2] as byte[];
                int rolledIndex = Convert.ToByte(__args[3]);
                if (plugin.OverrideWinningSlotRarity(itemIds, skinIndices, rolledIndex))
                    plugin._lastAction = "鱼转盘最终奖励已锁定：" + RarityName(plugin._slotRarity);
                else
                    plugin._lastAction = "所选品质没有可用皮肤，已保留本次游戏结果";
            }
            catch (Exception ex)
            {
                plugin.Logger.LogWarning("Slot final-result override failed: " + ex.Message);
            }
        }

        private static void AimAssistCanUsePostfix(object __instance, ref bool __result)
        {
            TrainerPlugin plugin = _instance;
            if (plugin != null && plugin.CanUseAimAssistOverride(__instance))
            {
                __result = true;
                plugin._aimPatchHitCount++;
            }
        }

        private static void AimTargetPositionPostfix(object __0, ref Vector3 __result)
        {
            TrainerPlugin plugin = _instance;
            if (plugin != null)
                plugin.ApplyAimTargetLead(plugin._tunedAimAssistInstance, __0, ref __result);
        }

        private bool OverrideWinningSlotRarity(byte[] itemIds, byte[] skinIndices, int rolledIndex)
        {
            if (itemIds == null || skinIndices == null || rolledIndex < 0 ||
                rolledIndex >= itemIds.Length || rolledIndex >= skinIndices.Length)
                return false;

            object rarity = Enum.ToObject(_rarityType, Mathf.Clamp(_slotRarity, 1, 3));
            byte skinIndex;
            if (TryGetSlotSkin(itemIds[rolledIndex], rarity, out skinIndex))
            {
                skinIndices[rolledIndex] = skinIndex;
                return true;
            }

            Array availableItems = _slotAvailableItemsProperty.GetValue(null, null) as Array;
            if (availableItems != null)
            {
                foreach (object item in availableItems)
                {
                    if (item == null || !TryGetRandomSkin(item, _itemSkinPresetProperty, rarity, out skinIndex))
                        continue;

                    itemIds[rolledIndex] = Convert.ToByte(_itemIdProperty.GetValue(item, null));
                    skinIndices[rolledIndex] = skinIndex;
                    return true;
                }
            }

            object boat = _boatProperty.GetValue(null, null);
            if (boat != null && TryGetRandomSkin(boat, _boatSkinPresetProperty, rarity, out skinIndex))
            {
                itemIds[rolledIndex] = byte.MaxValue;
                skinIndices[rolledIndex] = skinIndex;
                return true;
            }

            return false;
        }

        private bool TryGetSlotSkin(byte itemId, object rarity, out byte skinIndex)
        {
            skinIndex = 0;
            if (itemId == byte.MaxValue)
            {
                object boat = _boatProperty.GetValue(null, null);
                return boat != null && TryGetRandomSkin(boat, _boatSkinPresetProperty, rarity, out skinIndex);
            }

            Array availableItems = _slotAvailableItemsProperty.GetValue(null, null) as Array;
            if (availableItems == null)
                return false;

            foreach (object item in availableItems)
            {
                if (item != null && Convert.ToByte(_itemIdProperty.GetValue(item, null)) == itemId)
                    return TryGetRandomSkin(item, _itemSkinPresetProperty, rarity, out skinIndex);
            }

            return false;
        }

        private bool TryGetRandomSkin(
            object itemOrBoat,
            PropertyInfo skinPresetProperty,
            object rarity,
            out byte skinIndex)
        {
            skinIndex = 0;
            try
            {
                object preset = skinPresetProperty.GetValue(itemOrBoat, null);
                if (preset == null)
                    return false;

                skinIndex = Convert.ToByte(_getRandomSkinIndexMethod.Invoke(preset, new[] { rarity }));
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool CanApplyPatchedEffect(object expectedVitals)
        {
            try
            {
                object player;
                string reason;
                if (!TryGetOfflinePlayer(out player, out reason) || IsExplicitlyMultiplayer())
                    return false;

                if (expectedVitals == null)
                    return true;

                object localVitals = _vitalsProperty.GetValue(player, null);
                return ReferenceEquals(localVitals, expectedVitals);
            }
            catch
            {
                return false;
            }
        }

        private bool TryGetOfflinePlayer(out object player, out string reason)
        {
            player = null;
            reason = "未进入离线存档";

            try
            {
                if (!EnsureGameApi())
                {
                    reason = "当前游戏版本不兼容";
                    return false;
                }

                if (Convert.ToBoolean(_isUsingSteamField.GetValue(null)))
                {
                    reason = "检测到 Steam 联机传输";
                    return false;
                }

                object save = _curServerSaveProperty.GetValue(null, null);
                if (save == null)
                    return false;

                FieldInfo useSteam = save.GetType().GetField("UseSteam", AnyInstance);
                if (useSteam == null || Convert.ToBoolean(useSteam.GetValue(save)))
                {
                    reason = "当前为多人存档";
                    return false;
                }

                player = _localPlayerField.GetValue(null);
                if (player == null)
                {
                    reason = "等待本地玩家生成";
                    return false;
                }

                reason = "离线存档，可用";
                return true;
            }
            catch (Exception ex)
            {
                reason = "状态检测失败";
                Logger.LogDebug(ex);
                return false;
            }
        }

        private bool IsExplicitlyMultiplayer()
        {
            try
            {
                if (!EnsureGameApi())
                    return false;

                if (Convert.ToBoolean(_isUsingSteamField.GetValue(null)))
                    return true;

                object save = _curServerSaveProperty.GetValue(null, null);
                if (save == null)
                    return false;

                FieldInfo useSteam = save.GetType().GetField("UseSteam", AnyInstance);
                return useSteam != null && Convert.ToBoolean(useSteam.GetValue(save));
            }
            catch
            {
                return true;
            }
        }

        private void AddMoney(object player)
        {
            try
            {
                _addMoneyMethod.Invoke(null, new[] { (object)9999, player });
                _lastAction = "已增加 9999 金钱";
            }
            catch (Exception ex)
            {
                ReportActionError("加钱失败", ex);
            }
        }

        private void ToggleGodMode()
        {
            try
            {
                _toggleGodModeMethod.Invoke(null, null);
                bool enabled = GetGodMode();
                _requestedGodMode = enabled;
                _lastAction = enabled ? "无敌：开启" : "无敌：关闭";
            }
            catch (Exception ex)
            {
                ReportActionError("切换无敌失败", ex);
            }
        }

        private bool GetGodMode()
        {
            try
            {
                return _getGodModeMethod != null && Convert.ToBoolean(_getGodModeMethod.Invoke(null, null));
            }
            catch
            {
                return false;
            }
        }

        private void RestoreVitals(object player)
        {
            try
            {
                object vitals = _vitalsProperty.GetValue(player, null);
                if (vitals == null)
                    return;

                MethodInfo heal = vitals.GetType().GetMethod("Heal", AnyInstance, null, new[] { typeof(int) }, null);
                MethodInfo restoreFullness = vitals.GetType().GetMethod("RestoreFullness", AnyInstance, null, new[] { typeof(int) }, null);
                if (heal != null)
                    heal.Invoke(vitals, new object[] { 100 });
                if (restoreFullness != null)
                    restoreFullness.Invoke(vitals, new object[] { 100 });
            }
            catch (Exception ex)
            {
                ReportActionError("恢复状态失败", ex);
                _fullnessLock = false;
            }
        }

        private void ApplyMovement(object player)
        {
            bool needsMovementChanges = Math.Abs(_moveMultiplier - 1f) > 0.001f || Math.Abs(_jumpMultiplier - 1f) > 0.001f;
            if (!needsMovementChanges)
            {
                RestoreMovement();
                return;
            }

            try
            {
                object movement = _movementProperty.GetValue(player, null);
                if (movement == null)
                    return;

                if (!ReferenceEquals(_movementInstance, movement))
                {
                    RestoreMovement();
                    _movementInstance = movement;
                    Type movementType = movement.GetType();
                    _walkSpeedField = movementType.GetField("_walkSpeed", AnyInstance);
                    _sprintSpeedField = movementType.GetField("_sprintSpeed", AnyInstance);
                    _jumpForceField = movementType.GetField("_jumpForce", AnyInstance);
                    if (_walkSpeedField == null || _sprintSpeedField == null || _jumpForceField == null)
                        throw new MissingFieldException("PlayerMovement speed fields were not found.");

                    _originalWalkSpeed = Convert.ToSingle(_walkSpeedField.GetValue(movement));
                    _originalSprintSpeed = Convert.ToSingle(_sprintSpeedField.GetValue(movement));
                    _originalJumpForce = Convert.ToSingle(_jumpForceField.GetValue(movement));
                    _movementCaptured = true;
                }

                _walkSpeedField.SetValue(movement, _originalWalkSpeed * _moveMultiplier);
                _sprintSpeedField.SetValue(movement, _originalSprintSpeed * _moveMultiplier);
                _jumpForceField.SetValue(movement, _originalJumpForce * _jumpMultiplier);
            }
            catch (Exception ex)
            {
                ReportActionError("移动倍率应用失败", ex);
                _moveMultiplier = 1f;
                _jumpMultiplier = 1f;
                RestoreMovement();
            }
        }

        private void RestoreMovement()
        {
            if (!_movementCaptured || _movementInstance == null)
            {
                ClearMovementCapture();
                return;
            }

            try
            {
                _walkSpeedField.SetValue(_movementInstance, _originalWalkSpeed);
                _sprintSpeedField.SetValue(_movementInstance, _originalSprintSpeed);
                _jumpForceField.SetValue(_movementInstance, _originalJumpForce);
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
            finally
            {
                ClearMovementCapture();
            }
        }

        private void ClearMovementCapture()
        {
            _movementCaptured = false;
            _movementInstance = null;
            _walkSpeedField = null;
            _sprintSpeedField = null;
            _jumpForceField = null;
        }

        private void ApplyShinyChance()
        {
            if (!_shinyOverrideEnabled)
            {
                RestoreShinyChance();
                return;
            }

            try
            {
                object manager = _creatureManagerInstanceField.GetValue(null);
                if (manager == null)
                    return;

                if (!ReferenceEquals(manager, _creatureManagerInstance))
                {
                    RestoreShinyChance();
                    _creatureManagerInstance = manager;
                    _originalShinyChance = Convert.ToInt32(_shinyCreatureChanceField.GetValue(manager));
                    _shinyChanceCaptured = true;
                }

                _shinyCreatureChanceField.SetValue(manager, Mathf.Clamp(_shinyChance, 1, 100));
            }
            catch (Exception ex)
            {
                ReportActionError("极品动物概率应用失败", ex);
                _shinyOverrideEnabled = false;
                RestoreShinyChance();
            }
        }

        private void RestoreShinyChance()
        {
            if (!_shinyChanceCaptured || _creatureManagerInstance == null)
            {
                ClearShinyCapture();
                return;
            }

            try
            {
                _shinyCreatureChanceField.SetValue(_creatureManagerInstance, _originalShinyChance);
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
            finally
            {
                ClearShinyCapture();
            }
        }

        private void ClearShinyCapture()
        {
            _creatureManagerInstance = null;
            _originalShinyChance = 0;
            _shinyChanceCaptured = false;
        }

        private void CycleShinyChance()
        {
            if (!_shinyOverrideEnabled)
            {
                _shinyOverrideEnabled = true;
                _shinyChance = 10;
            }
            else if (_shinyChance < 25)
            {
                _shinyChance = 25;
            }
            else if (_shinyChance < 50)
            {
                _shinyChance = 50;
            }
            else if (_shinyChance < 100)
            {
                _shinyChance = 100;
            }
            else
            {
                _shinyOverrideEnabled = false;
                RestoreShinyChance();
            }

            _lastAction = _shinyOverrideEnabled
                ? "极品动物概率：" + _shinyChance + "%"
                : "极品动物概率：恢复游戏默认";
        }

        private void CycleGambleChance()
        {
            if (!_gambleOverrideEnabled)
            {
                _gambleOverrideEnabled = true;
                _gambleWinChance = 25;
            }
            else if (_gambleWinChance < 50)
            {
                _gambleWinChance = 50;
            }
            else if (_gambleWinChance < 75)
            {
                _gambleWinChance = 75;
            }
            else if (_gambleWinChance < 100)
            {
                _gambleWinChance = 100;
            }
            else
            {
                _gambleOverrideEnabled = false;
            }

            _lastAction = _gambleOverrideEnabled
                ? "赌博轮盘胜率：" + _gambleWinChance + "%"
                : "赌博轮盘胜率：恢复游戏默认";
        }

        private void CycleSlotRarity()
        {
            if (!_slotRarityOverrideEnabled)
            {
                _slotRarityOverrideEnabled = true;
                _slotRarity = 1;
            }
            else if (_slotRarity < 3)
            {
                _slotRarity++;
            }
            else
            {
                _slotRarityOverrideEnabled = false;
            }

            _lastAction = _slotRarityOverrideEnabled
                ? "鱼转盘皮肤品质：" + RarityName(_slotRarity)
                : "鱼转盘皮肤品质：恢复游戏默认";
        }

        private void SetSlotRarity(int rarity)
        {
            _slotRarity = Mathf.Clamp(rarity, 1, 3);
            _slotRarityOverrideEnabled = true;
            _lastAction = "鱼转盘皮肤品质：" + RarityName(_slotRarity);
        }

        private static string RarityName(int rarity)
        {
            if (rarity == 1) return "普通（Common）";
            if (rarity == 2) return "稀有（Rare）";
            if (rarity == 3) return "传奇（Legendary）";
            return "游戏默认";
        }

        private bool IsPrivateInviteRoom()
        {
            try
            {
                if (!EnsureGameApi() || !Convert.ToBoolean(_isUsingSteamField.GetValue(null)))
                    return false;

                object save = _curServerSaveProperty.GetValue(null, null);
                if (save == null)
                    return false;

                FieldInfo useSteam = save.GetType().GetField("UseSteam", AnyInstance);
                FieldInfo isPublic = save.GetType().GetField("IsPublic", AnyInstance);
                if (useSteam == null || isPublic == null ||
                    !Convert.ToBoolean(useSteam.GetValue(save)) || Convert.ToBoolean(isPublic.GetValue(save)))
                    return false;

                return _localPlayerField.GetValue(null) != null && GetCurrentLobbyId() != null;
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
                return false;
            }
        }

        private bool IsPrivateInviteHostRoom()
        {
            try
            {
                if (!IsPrivateInviteRoom())
                    return false;

                object connectionManager = _connectionManagerInstanceField.GetValue(null);
                object networkManager = connectionManager == null ? null : _networkManagerField.GetValue(connectionManager);
                if (networkManager == null)
                    return false;

                PropertyInfo isServerStarted = networkManager.GetType().GetProperty("IsServerStarted", AnyInstance);
                return isServerStarted != null && Convert.ToBoolean(isServerStarted.GetValue(networkManager, null));
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
                return false;
            }
        }

        private bool CanUseAimAssistOverride(object aimAssistInstance)
        {
            try
            {
                if (!_aimAssistEnabled || aimAssistInstance == null || !EnsureGameApi())
                    return false;

                object localPlayer = _localPlayerField.GetValue(null);
                object aimAssistPlayer = _aimAssistPlayerField.GetValue(aimAssistInstance);
                if (localPlayer == null || !ReferenceEquals(localPlayer, aimAssistPlayer))
                    return false;

                if (Convert.ToBoolean(_blockInputsProperty.GetValue(localPlayer, null)))
                    return false;

                object playerCamera = _cameraProperty.GetValue(localPlayer, null);
                if (playerCamera == null || !Convert.ToBoolean(_mouseLockedProperty.GetValue(playerCamera, null)))
                    return false;

                bool allowed;
                if (IsExplicitlyMultiplayer())
                {
                    allowed = _consentConfirmedForLobby && IsPrivateInviteHostRoom();
                }
                else
                {
                    object offlinePlayer;
                    string reason;
                    allowed = TryGetOfflinePlayer(out offlinePlayer, out reason) &&
                        ReferenceEquals(localPlayer, offlinePlayer);
                }

                if (allowed)
                    ApplyAimAssistTuning(aimAssistInstance);
                return allowed;
            }
            catch
            {
                return false;
            }
        }

        private void ApplyAimAssistTuning(object aimAssistInstance)
        {
            try
            {
                if (!_aimAssistSettingsCaptured || !ReferenceEquals(_tunedAimAssistInstance, aimAssistInstance))
                {
                    RestoreAimAssistTuning();
                    _tunedAimAssistInstance = aimAssistInstance;
                    _originalAimMaxTargetDistance = Convert.ToSingle(_aimAssistMaxTargetDistanceField.GetValue(aimAssistInstance));
                    _originalAimAcquireAngle = Convert.ToSingle(_aimAssistAcquireAngleField.GetValue(aimAssistInstance));
                    _originalAimTrackingBreakAngle = Convert.ToSingle(_aimAssistTrackingBreakAngleField.GetValue(aimAssistInstance));
                    _originalAimTargetScanInterval = Convert.ToSingle(_aimAssistTargetScanIntervalField.GetValue(aimAssistInstance));
                    _originalAimMaxRotationSpeed = Convert.ToSingle(_aimAssistMaxRotationSpeedField.GetValue(aimAssistInstance));
                    _originalAimTrackingSharpness = Convert.ToSingle(_aimAssistTrackingSharpnessField.GetValue(aimAssistInstance));
                    _aimAssistSettingsCaptured = true;
                }

                float multiplier = Mathf.Clamp(_aimAssistSpeedMultiplier, 1f, 12f);
                _aimAssistMaxTargetDistanceField.SetValue(
                    aimAssistInstance, Mathf.Max(_originalAimMaxTargetDistance, 120f));
                _aimAssistAcquireAngleField.SetValue(
                    aimAssistInstance, Mathf.Max(_originalAimAcquireAngle, _aimAssistAcquireAngle));
                _aimAssistTrackingBreakAngleField.SetValue(
                    aimAssistInstance, Mathf.Max(_originalAimTrackingBreakAngle, _aimAssistAcquireAngle + 20f));
                _aimAssistTargetScanIntervalField.SetValue(
                    aimAssistInstance, Mathf.Min(_originalAimTargetScanInterval, 0.03f));
                _aimAssistMaxRotationSpeedField.SetValue(
                    aimAssistInstance, Mathf.Max(_originalAimMaxRotationSpeed, 90f) * multiplier);
                _aimAssistTrackingSharpnessField.SetValue(
                    aimAssistInstance, Mathf.Max(_originalAimTrackingSharpness, 5f) * multiplier);
                _aimAssistCacheSettingsMethod.Invoke(aimAssistInstance, null);
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
        }

        private void RestoreAimAssistTuning()
        {
            if (!_aimAssistSettingsCaptured || _tunedAimAssistInstance == null)
            {
                _tunedAimAssistInstance = null;
                _aimAssistSettingsCaptured = false;
                return;
            }

            try
            {
                _aimAssistMaxTargetDistanceField.SetValue(_tunedAimAssistInstance, _originalAimMaxTargetDistance);
                _aimAssistAcquireAngleField.SetValue(_tunedAimAssistInstance, _originalAimAcquireAngle);
                _aimAssistTrackingBreakAngleField.SetValue(_tunedAimAssistInstance, _originalAimTrackingBreakAngle);
                _aimAssistTargetScanIntervalField.SetValue(_tunedAimAssistInstance, _originalAimTargetScanInterval);
                _aimAssistMaxRotationSpeedField.SetValue(_tunedAimAssistInstance, _originalAimMaxRotationSpeed);
                _aimAssistTrackingSharpnessField.SetValue(_tunedAimAssistInstance, _originalAimTrackingSharpness);
                _aimAssistCacheSettingsMethod.Invoke(_tunedAimAssistInstance, null);
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
            finally
            {
                _tunedAimAssistInstance = null;
                _aimAssistSettingsCaptured = false;
                _rigVelocityProperty = null;
            }
        }

        private void ApplyAimTargetLead(object aimAssistInstance, object creature, ref Vector3 targetPosition)
        {
            if (creature == null || _aimAssistLeadSeconds <= 0.001f ||
                !CanUseAimAssistOverride(aimAssistInstance))
                return;

            try
            {
                object rig = _itemRigProperty.GetValue(creature, null);
                if (rig == null)
                    return;

                if (_rigVelocityProperty == null ||
                    !_rigVelocityProperty.DeclaringType.IsAssignableFrom(rig.GetType()))
                {
                    _rigVelocityProperty = rig.GetType().GetProperty("linearVelocity", AnyInstance) ??
                        rig.GetType().GetProperty("velocity", AnyInstance);
                }

                if (_rigVelocityProperty == null)
                    return;

                object velocityValue = _rigVelocityProperty.GetValue(rig, null);
                if (velocityValue is Vector3)
                {
                    targetPosition += (Vector3)velocityValue * Mathf.Clamp(_aimAssistLeadSeconds, 0f, 0.5f);
                    _aimLeadPatchHitCount++;
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
        }

        private void ToggleAimAssist()
        {
            if (_aimAssistEnabled)
            {
                SetAimAssistEnabled(false, true, "武器瞄准辅助：关闭");
                return;
            }

            object player;
            string reason;
            bool offline = !IsExplicitlyMultiplayer() && TryGetOfflinePlayer(out player, out reason);
            bool privateInviteHost = IsPrivateInviteHostRoom();
            if (!offline && !privateInviteHost)
            {
                _lastAction = "瞄准辅助仅限单人或由本机主持的好友邀请房";
                return;
            }

            if (privateInviteHost && !_consentConfirmedForLobby)
            {
                _lastAction = "请先勾选“我已获得当前房间内所有成员同意”";
                return;
            }

            SetAimAssistEnabled(true, true, "武器瞄准辅助：开启");
        }

        private void SetAimAssistEnabled(bool enabled, bool announce, string message)
        {
            if (enabled && IsExplicitlyMultiplayer() &&
                (!IsPrivateInviteHostRoom() || !_consentConfirmedForLobby))
            {
                _lastAction = "好友房中请先确认已获得当前房间全员同意";
                return;
            }

            _aimAssistEnabled = enabled;
            _lastAction = message;

            if (!enabled)
                RestoreAimAssistTuning();

            if (enabled && announce && IsPrivateInviteHostRoom() && !_voiceNoticePlayedForLobby)
            {
                PlayAimAssistVoiceNotice();
                _voiceNoticePlayedForLobby = true;
            }
        }

        private object GetCurrentLobbyId()
        {
            try
            {
                object lobbyId = _currentLobbyIdProperty.GetValue(null, null);
                if (lobbyId == null)
                    return null;

                FieldInfo rawId = lobbyId.GetType().GetField("m_SteamID", AnyInstance);
                if (rawId != null && Convert.ToUInt64(rawId.GetValue(lobbyId)) == 0UL)
                    return null;
                return lobbyId;
            }
            catch
            {
                return null;
            }
        }

        private string GetLobbyIdentity(object lobbyId)
        {
            try
            {
                FieldInfo rawId = lobbyId.GetType().GetField("m_SteamID", AnyInstance);
                return rawId == null ? lobbyId.ToString() : Convert.ToUInt64(rawId.GetValue(lobbyId)).ToString();
            }
            catch
            {
                return string.Empty;
            }
        }

        private void UpdatePrivateRoomSession()
        {
            try
            {
                object lobbyId = GetCurrentLobbyId();
                if (lobbyId == null)
                    return;

                string identity = GetLobbyIdentity(lobbyId);
                if (string.Equals(identity, _currentLobbyIdentity, StringComparison.Ordinal))
                    return;

                if (_aimAssistEnabled)
                    SetAimAssistEnabled(false, false, "进入新的好友房，瞄准辅助已关闭");
                _currentLobbyIdentity = identity;
                _consentConfirmedForLobby = false;
                _voiceNoticePlayedForLobby = false;
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
        }

        private void ResetPrivateRoomSession()
        {
            _currentLobbyIdentity = string.Empty;
            _consentConfirmedForLobby = false;
            _voiceNoticePlayedForLobby = false;
        }

        private void PlayAimAssistVoiceNotice()
        {
            try
            {
                if (!EnsureAimAssistVoiceLoaded())
                    return;

                Camera camera = Camera.main;
                Vector3 position = camera == null ? Vector3.zero : camera.transform.position;
                AudioSource.PlayClipAtPoint(_aimAssistNoticeClip, position, 0.85f);
            }
            catch (Exception ex)
            {
                Logger.LogWarning("Aim-assist voice notice could not be played: " + ex.Message);
            }
        }

        private bool EnsureAimAssistVoiceLoaded()
        {
            if (_aimAssistNoticeClip != null)
                return true;
            if (_voiceLoadAttempted)
                return false;
            _voiceLoadAttempted = true;

            try
            {
                string pluginDirectory = Path.GetDirectoryName(Info.Location);
                string voicePath = Path.Combine(pluginDirectory, "AimAssistNotice.wav");
                byte[] bytes = File.ReadAllBytes(voicePath);
                int formatOffset = -1;
                int dataOffset = -1;
                int dataSize = 0;

                for (int offset = 12; offset + 8 <= bytes.Length;)
                {
                    uint chunkId = BitConverter.ToUInt32(bytes, offset);
                    int chunkSize = BitConverter.ToInt32(bytes, offset + 4);
                    int chunkDataOffset = offset + 8;
                    if (chunkSize < 0 || chunkDataOffset + chunkSize > bytes.Length)
                        break;
                    if (chunkId == 0x20746D66U)
                        formatOffset = chunkDataOffset;
                    else if (chunkId == 0x61746164U)
                    {
                        dataOffset = chunkDataOffset;
                        dataSize = chunkSize;
                        break;
                    }
                    offset = chunkDataOffset + chunkSize + (chunkSize & 1);
                }

                if (formatOffset < 0 || dataOffset < 0 || dataSize <= 0)
                    throw new InvalidDataException("WAV fmt/data chunk missing.");

                ushort audioFormat = BitConverter.ToUInt16(bytes, formatOffset);
                ushort channels = BitConverter.ToUInt16(bytes, formatOffset + 2);
                int sampleRate = BitConverter.ToInt32(bytes, formatOffset + 4);
                ushort bitsPerSample = BitConverter.ToUInt16(bytes, formatOffset + 14);
                if (audioFormat != 1 || (channels != 1 && channels != 2) || bitsPerSample != 16)
                    throw new InvalidDataException("Voice WAV must be PCM 16-bit mono/stereo.");

                int sampleCount = dataSize / 2;
                int frameCount = sampleCount / channels;
                float[] samples = new float[sampleCount];
                for (int index = 0; index < sampleCount; index++)
                    samples[index] = BitConverter.ToInt16(bytes, dataOffset + index * 2) / 32768f;

                _aimAssistNoticeClip = AudioClip.Create(
                    "AimAssistNotice", frameCount, channels, sampleRate, false);
                _aimAssistNoticeClip.SetData(samples, 0);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogWarning("Aim-assist voice file could not be loaded: " + ex.Message);
                return false;
            }
        }

        private void UpdateFrameStats()
        {
            float delta = Time.unscaledDeltaTime;
            if (delta > 0.0001f && delta < 1f)
                _smoothedFrameTime = Mathf.Lerp(_smoothedFrameTime, delta, 0.08f);
        }

        private void CycleCameraFov()
        {
            if (!_fovOverrideEnabled)
            {
                _fovOverrideEnabled = true;
                _cameraFov = 75f;
            }
            else if (_cameraFov < 90f)
            {
                _cameraFov = 90f;
            }
            else if (_cameraFov < 105f)
            {
                _cameraFov = 105f;
            }
            else if (_cameraFov < 120f)
            {
                _cameraFov = 120f;
            }
            else
            {
                _fovOverrideEnabled = false;
                RestoreCameraFov();
            }

            _lastAction = _fovOverrideEnabled
                ? "本地镜头 FOV：" + _cameraFov.ToString("0")
                : "本地镜头 FOV：恢复游戏默认";
        }

        private void ApplyCameraFov()
        {
            if (!_fovOverrideEnabled)
            {
                RestoreCameraFov();
                return;
            }

            try
            {
                Camera camera = Camera.main;
                if (camera == null)
                    return;

                if (!ReferenceEquals(_cameraInstance, camera))
                {
                    RestoreCameraFov();
                    _cameraInstance = camera;
                    _originalCameraFov = camera.fieldOfView;
                    _cameraFovCaptured = true;
                }

                camera.fieldOfView = Mathf.Clamp(_cameraFov, 55f, 120f);
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
                _fovOverrideEnabled = false;
                RestoreCameraFov();
            }
        }

        private void RestoreCameraFov()
        {
            if (!_cameraFovCaptured)
            {
                _cameraInstance = null;
                return;
            }

            try
            {
                if (_cameraInstance != null)
                    _cameraInstance.fieldOfView = _originalCameraFov;
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex);
            }
            finally
            {
                _cameraInstance = null;
                _originalCameraFov = 0f;
                _cameraFovCaptured = false;
            }
        }

        private void DisableOfflineFeatures(string message)
        {
            _fullnessLock = false;
            _moveMultiplier = 1f;
            _jumpMultiplier = 1f;
            _damageMultiplier = 1f;
            _healthMultiplier = 1f;
            _shinyOverrideEnabled = false;
            _gambleOverrideEnabled = false;
            _slotRarityOverrideEnabled = false;
            _lastSelectedBetColor = null;
            RestoreMovement();
            RestoreShinyChance();

            if (_requestedGodMode && GetGodMode())
            {
                try
                {
                    _toggleGodModeMethod.Invoke(null, null);
                }
                catch (Exception ex)
                {
                    Logger.LogDebug(ex);
                }
            }

            _requestedGodMode = false;
            _lastAction = message;
        }

        private void DisableAllFeatures(string message)
        {
            if (_aimAssistEnabled)
                SetAimAssistEnabled(false, true, "武器瞄准辅助：关闭");
            DisableOfflineFeatures(message);
            _fovOverrideEnabled = false;
            _fpsOverlayEnabled = false;
            RestoreCameraFov();
            _lastAction = message;
        }

        private void OnDisable()
        {
            DisableAllFeatures("插件已停用");
        }

        private void OnDestroy()
        {
            DisableAllFeatures("插件已卸载");
            if (_harmony != null)
            {
                try { _harmony.UnpatchSelf(); }
                catch (Exception ex) { Logger.LogDebug(ex); }
            }
            _patchesInstalled = false;
            if (_aimAssistNoticeClip != null)
            {
                try { Destroy(_aimAssistNoticeClip); }
                catch (Exception ex) { Logger.LogDebug(ex); }
                _aimAssistNoticeClip = null;
            }
            if (ReferenceEquals(_instance, this))
                _instance = null;
        }

        private void EnsureStyles()
        {
            if (_titleStyle != null)
                return;

            _titleStyle = new GUIStyle(GUI.skin.label);
            _titleStyle.fontSize = 16;
            _titleStyle.fontStyle = FontStyle.Bold;
            _titleStyle.alignment = TextAnchor.MiddleCenter;

            _statusStyle = new GUIStyle(GUI.skin.label);
            _statusStyle.fontStyle = FontStyle.Bold;
            _statusStyle.alignment = TextAnchor.MiddleCenter;

            _smallStyle = new GUIStyle(GUI.skin.label);
            _smallStyle.fontSize = 11;
            _smallStyle.wordWrap = true;
        }

        private void ReportActionError(string action, Exception ex)
        {
            Exception useful = ex is TargetInvocationException && ex.InnerException != null ? ex.InnerException : ex;
            _lastAction = action + "：" + useful.Message;
            Logger.LogWarning(_lastAction);
        }

        private static float NextMultiplier(float current)
        {
            if (current < 1.5f) return 2f;
            if (current < 2.5f) return 3f;
            if (current < 4f) return 5f;
            return 1f;
        }

        private static float NextCombatMultiplier(float current)
        {
            if (current < 1.5f) return 2f;
            if (current < 2.5f) return 3f;
            if (current < 4f) return 5f;
            if (current < 7.5f) return 10f;
            return 1f;
        }

        private static float RoundQuarter(float value)
        {
            return Mathf.Round(value * 4f) / 4f;
        }
    }
}
