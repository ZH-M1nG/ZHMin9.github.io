[CmdletBinding()]
param(
    [string]$GamePath = 'D:\Steam\steamapps\common\How to Fish'
)

$ErrorActionPreference = 'Stop'

function Resolve-GameRoot {
    param([string]$RequestedPath)

    $resolved = (Resolve-Path -LiteralPath $RequestedPath).Path
    $candidates = @(
        $resolved,
        (Join-Path $resolved 'How to Fish')
    )

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'How to Fish.exe') -PathType Leaf) {
            return $candidate
        }
    }

    throw "在 '$RequestedPath' 或其 How to Fish 子目录中找不到 How to Fish.exe。"
}

$gameRoot = Resolve-GameRoot -RequestedPath $GamePath
$payloadRoot = Join-Path $PSScriptRoot 'payload'
$pluginSource = Join-Path $payloadRoot 'BepInEx\plugins\HowToFishOfflineTrainer.dll'

if (-not (Test-Path -LiteralPath $pluginSource -PathType Leaf)) {
    throw "安装包不完整：找不到 $pluginSource"
}

$backupRoot = Join-Path $gameRoot ('HowToFishTrainer.Backup.' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$madeBackup = $false
$copied = 0
$skipped = 0

foreach ($source in Get-ChildItem -LiteralPath $payloadRoot -Recurse -File) {
    $relative = $source.FullName.Substring($payloadRoot.Length).TrimStart('\')
    $target = Join-Path $gameRoot $relative
    $targetParent = Split-Path -Parent $target

    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $sourceHash = (Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash
        $targetHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
        if ($sourceHash -eq $targetHash) {
            $skipped++
            continue
        }

        $backupTarget = Join-Path $backupRoot $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $backupTarget) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $backupTarget -Force
        $madeBackup = $true
    }

    New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
    Copy-Item -LiteralPath $source.FullName -Destination $target -Force
    $copied++
}

Write-Host "安装完成：$gameRoot" -ForegroundColor Green
Write-Host "已写入 $copied 个文件，跳过 $skipped 个相同文件。"
if ($madeBackup) {
    Write-Host "原文件备份：$backupRoot" -ForegroundColor Yellow
}
Write-Host '好友无需安装。你作为 Private 好友房房主，须先在紫色区域勾选“已获得当前房间全员同意”，再开启瞄准辅助。'
Write-Host '不会发送聊天或网络提示；提示语音只在你的电脑上每房首次开启时播放一次。'
